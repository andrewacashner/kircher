# Revision history for kircher

## Development

------------    ------------ 
2019/02/04      Begun
2019/10         New version in Haskell

## 0.1.0.0 -- 2019/10/31

* Under construction
